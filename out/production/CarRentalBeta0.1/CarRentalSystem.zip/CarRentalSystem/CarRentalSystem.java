
package CarRentalSystem;

import java.io.File;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;


public class CarRentalSystem
{
    static Home Frame = new Home();
    static Login Login = new Login();
    static user_choice_gui userchoice = new user_choice_gui();
    static SearchCar searchCar = new SearchCar();
    static EditCar editCar = new EditCar();
    static PostCar post = new PostCar();
    static  posting_user posting_gui = new posting_user();
    static user_posts User_Posts = new user_posts();



    public static void main(String[] args) {



    }
}
