package CarRentalSystem;

import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class GUI_admin extends JFrame
{
    JButton Return , addcar, viewcars, viewclients, editcars, editclients, searchforcars, viewbookings;

    GUI_admin()
    {

        setSize(500,500);
        setTitle("Admin");
        setVisible(true);

        getContentPane().setBackground(Color.DARK_GRAY);
        setLocationRelativeTo(null);
        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        Return= new JButton("Return");
        Return.setBounds(180,330, 120, 50);
        Return.addActionListener(new Buttonsaver());
        add(Return);
        viewcars= new JButton("view cars");
        viewcars.setBounds(30, 120, 120, 50);
        viewcars.addActionListener(new Buttonsaver());
        add(viewcars);
        viewclients= new JButton("view clients");
        viewclients.setBounds(190,120, 120, 50);
        viewclients.addActionListener(new Buttonsaver());
        add(viewclients);

        viewbookings= new JButton("View bookings");
        viewbookings.setBounds(340,120, 120, 50);
        viewbookings.addActionListener(new Buttonsaver());
        add(viewbookings);

    }

    private class Buttonsaver implements ActionListener {

        public Buttonsaver() {

        }

        @Override
        public void actionPerformed(ActionEvent e) {
            if (e.getSource().equals(Return)) {
                CarRentalSystem.Frame.setVisible(true);
                setVisible(false);
                dispose();

            }

            if (e.getSource().equals(viewcars)) {
                AdminCars AC=new AdminCars(1);
                setVisible(false);
                dispose();

            }
            if (e.getSource().equals(viewclients)) {
                AdminUsers AU=new AdminUsers();
                setVisible(false);
                dispose();

            }
            if (e.getSource().equals(viewbookings)) {
                AdminBookings AB=new AdminBookings();
                setVisible(false);
                dispose();

            }
        }


    }
}