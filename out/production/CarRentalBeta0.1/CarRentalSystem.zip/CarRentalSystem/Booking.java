
package CarRentalSystem;

import java.io.File;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.HashMap;


public class Booking {
    Car c;
    Person p;
    private float amount,amount_due;
    private String payment;
    public ArrayList<String> bookingarray = new ArrayList<>();
    static public HashMap<String,ArrayList> bookingmap = new HashMap<>();

    public Booking()
    {
        
    }
    public Booking(Car c,String PNum,float amount, String payment)
    {
        this.c = c;
        this.p = p;
        ArrayList<String> avb =c.carmap.get(PNum);
        avb.remove(7);
        avb.add(7,"Unavailable");
        c.carmap.replace(PNum,avb);
        this.amount = amount;
        this.amount_due = amount;
        this.payment = payment;
        bookingarray.add(String.valueOf(amount_due));
        bookingarray.add(payment);
        bookingarray.add(String.valueOf(amount));
        bookingmap.put(c.Platenum,bookingarray);

        try
        {
            File bookingdata = new File("C:\\Users\\ggrna\\Desktop\\bookingdata.dat");
            FileOutputStream foss=new FileOutputStream(bookingdata);
            ObjectOutputStream ooss=new ObjectOutputStream(foss);

            ooss.writeObject(bookingmap);
            ooss.flush();
            ooss.close();
            foss.close();

        }
        catch(Exception e)
        {

        }
    }


    
}
