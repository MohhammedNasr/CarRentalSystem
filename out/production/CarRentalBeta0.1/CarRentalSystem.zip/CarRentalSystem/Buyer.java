
package CarRentalSystem;


public class Buyer extends Person
{
    
}
