package CarRentalSystem;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class posting_user extends JFrame
{
    JButton Return=new JButton("Return");
    JButton post=new JButton("Post a Car");
    JButton posts=new JButton("My Posts");
    public posting_user()
    {
        Return.addActionListener(new Buttonsaver());
        post.addActionListener(new Buttonsaver());
        posts.addActionListener(new Buttonsaver());
        setSize(500,500);
        setTitle("User");
        setLayout(null);
        getContentPane().setBackground(Color.DARK_GRAY);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        Return.setBounds(100, 300, 120, 50);
        post.setBounds(150, 350, 120, 50);
        posts.setBounds(250, 450, 120, 50);
        add(Return);
        add(post);
        add(posts);

    }

    private class Buttonsaver implements ActionListener {

        public Buttonsaver() {

        }

        @Override
        public void actionPerformed(ActionEvent e) {
            if (e.getSource().equals(Return)) {
                CarRentalSystem.userchoice.setVisible(true);
                CarRentalSystem.posting_gui.setVisible(false);
                dispose();

            }
            if (e.getSource().equals(post)) {
                CarRentalSystem.post.setVisible(true);
                CarRentalSystem.posting_gui.setVisible(false);
                dispose();

            }

            if (e.getSource().equals(posts)) {
                CarRentalSystem.User_Posts.setVisible(true);
                CarRentalSystem.posting_gui.setVisible(false);
                dispose();

            }




        }
    }
}
