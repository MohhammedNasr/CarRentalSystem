
package CarRentalSystem;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Payment_Gui {
    JRadioButton visa,cash;
    JLabel car_make,car_model,model_year,car_color,milage,transmition;
    
}
