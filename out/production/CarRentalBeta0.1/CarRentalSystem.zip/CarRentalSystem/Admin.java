
package CarRentalSystem;


public class Admin extends Person
{
    
}
