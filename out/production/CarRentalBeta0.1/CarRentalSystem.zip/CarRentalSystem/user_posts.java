package CarRentalSystem;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class user_posts extends JFrame
{
    JButton Return=new JButton("Return");
    JButton edit=new JButton("Edit");
    JButton delete=new JButton("Delete");
    JScrollPane CTScroll=new JScrollPane();
    JTable CarList=new JTable();
    JPanel TablePanel=new JPanel();
    String CarsList[][]=new String[35][5];
    String Headers[]={ "Make", "Model", "Year", "Color", "Price"};
    public user_posts()
    {
        Return.addActionListener(new Buttonsaver());
        edit.addActionListener(new Buttonsaver());
        delete.addActionListener(new Buttonsaver());
        setSize(500,500);
        setTitle("User");
        TablePanel.setBackground(Color.DARK_GRAY);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        CarList.setModel(new javax.swing.table.DefaultTableModel(
                CarsList,
                Headers
        ) {
            public Class getColumnClass(int columnIndex) {
                return String.class;
            }
            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return false;
            }
        });
        CTScroll.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        CTScroll.setViewportView(CarList);
        TablePanel.add(CTScroll);
        Return.setSize(100, 50);
        edit.setSize(100, 50);
        delete.setSize(100, 50);
        TablePanel.add(Return);
        TablePanel.add(edit);
        TablePanel.add(delete);
        add(TablePanel);
    }

    private class Buttonsaver implements ActionListener {

        public Buttonsaver() {

        }

        @Override
        public void actionPerformed(ActionEvent e) {
            if (e.getSource().equals(Return)) {
                CarRentalSystem.posting_gui.setVisible(true);
                CarRentalSystem.User_Posts.setVisible(false);
                dispose();

            }

            if (e.getSource().equals(edit))
            {
                int sel_row=CarList.getSelectedRow();
                setVisible(true);
                setVisible(false);
                dispose();

            }


        }
    }
}