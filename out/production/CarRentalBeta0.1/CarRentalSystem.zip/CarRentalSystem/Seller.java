
package CarRentalSystem;


public class Seller extends Person
{
    
}
